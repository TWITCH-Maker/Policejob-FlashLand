Locales ['en'] = {
	['unlocked'] = '🔓',
	['locked'] = '🔒',
	['press_button'] = '[E] %s',
}
