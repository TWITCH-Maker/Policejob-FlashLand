Locales ['de'] = {
	['unlocked'] = '🔓',
	['locked'] = '🔐',
	['press_button'] = '[E] %s',
}