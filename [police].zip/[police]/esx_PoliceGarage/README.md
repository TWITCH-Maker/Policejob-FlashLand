# POLICE GARAGE

### Requirements
- progressBar

You can get my version of `progressBar` from my github repository:
https://github.com/Hamza8700/fivem_scripts

### Installation
1) Drag & drop the folder into your `resources` server folder.
2) Configure the config file to your liking.
3) Add `start esx_poliecGarage` to your server config.

### Showcase
- https://streamable.com/u1e6x