Config = {}
Config.Marker = {
	Pos   = {x = 444.66662597656, y = -974.96911621094, z = 31.00},
	Size  = {x = 2.0, y = 2.0, z = 1.0},
	Color = {r = 26, g = 55, b = 186},
	Hint = 'Appuyez sur ~INPUT_PICKUP~ pour ouvrir le Casier Judiciaire.',
	Type = 22,
}
