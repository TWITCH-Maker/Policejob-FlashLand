local Interior = GetInteriorAtCoords(440.84, -983.14, 30.69)

LoadInterior(Interior)