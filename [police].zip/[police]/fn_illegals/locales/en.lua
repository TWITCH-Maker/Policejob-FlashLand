Locales['en'] = {
    ["marker_do_txt"] = "~INPUT_TALK~ Pour Ouvrir Le Menu Illégal",
    ["not_items_notify"] = "Tu n'as pas de coke/weed/opium/meth",
    ["dialog_title"] = "Combien ? ",
    ["amount_invalid"] = "Montant Invalide",
}