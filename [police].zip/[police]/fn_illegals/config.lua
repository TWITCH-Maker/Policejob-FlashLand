Config = {}
 
Config.MarkerColor = {r = 0, g = 200, b = 204}
Config.JobName = "police" -- required  job
Config.Bonus = 25 -- money bonus

Config.CountMoney = 75
Config.BonusMoney = 25

Config.Items = {"weed", "coke", "meth", "opium"} -- List of the illegal items (do not add weapons!)

Config.Zones = { 
    {type = 22, x = 477.91, y = -982.78, z = 24.91} -- script zones
}

Config.Locale = "en" 