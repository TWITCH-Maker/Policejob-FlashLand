Locales ['fr'] = {
	['unlocked'] = '~g~Ouvert~s~',
	['locked'] = '~r~Fermé~s~',
	['press_button'] = '[E] %s',
}
