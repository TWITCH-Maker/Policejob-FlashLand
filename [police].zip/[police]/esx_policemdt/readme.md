https://www.ModFreakz.net
https://discord.gg/ukgQa5K

Requirements
- ESX

Installation
- 1. Extract into resource folder.
- 2. Start esx_policemdt in server.cfg.
- 3. Import SQL files - no order needed
- 4. MDT pc locations in client.lua configured to some police stations around the map

